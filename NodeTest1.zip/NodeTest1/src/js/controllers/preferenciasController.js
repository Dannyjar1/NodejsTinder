var Preferencias=require("../models/preferencias");
    express=require("express");
    router=express.Router();

router.post('/crearPreferencias',(req,response)=>{
    var body=req.body;
    console.log(body);
     Preferencias.insertMany({
        hobbie:body.hobbie,
        generoPreferido:body.generoPreferido,
        edadminima:body.edadminima,
        edadmaxima:body.edadmaxima,
        ciudades:body.ciudades,
        busco:body.busco
    }).then(function () {
        console.log("Successfully saved defult items to DB");
        response.status(200).json("Datos Guardados");
      })
      .catch(function (err) {
        console.log(err);
        response.status(500).json("Ocurrio un error al guardar")
      });;

});


router.post('/editarPreferencia',(req,response)=>{
  var body=req.body;
  Preferencias.updateOne({
    _id:body.id //decir que campo voy actualizar
  },{
    $set:{
      hobbie:body.hobbie,
      generoPreferido:body.generoPreferido,
      edadminima:body.edadminima,
      edadmaxima:body.edadmaxima,
      ciudades:body.ciudades,
      busco:body.busco
        
    }
  }).then(function () {
    console.log("Successfully saved defult items to DB");
    response.status(200).json("Datos Actualizados");
  })
  .catch(function (err) {
    console.log(err);
    response.status(500).json("Ocurrio un error al guardar")
  });
});

router.post('/eliminarPreferencia',(req,response)=>{
  var body=req.body;
  Preferencias.deleteOne({
    _id:body.id

  }).then(function () {
    console.log("Successfully saved defult items to DB");
    response.status(200).json("Datos eliminados");
  })
  .catch(function (err) {
    console.log(err);
    response.status(500).json("Ocurrio un error al guardar")
  });
});
module.exports=router;